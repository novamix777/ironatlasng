(function(){
'use strict';

// ══════════════════════════
//  LOADER
// ══════════════════════════
window.addEventListener('load',function(){
    setTimeout(function(){
        document.getElementById('loader').classList.add('done');
    },2500);
});

// ══════════════════════════
//  MATRIX RAIN
// ══════════════════════════
var mc=document.getElementById('matrix');
if(mc){
    var mx=mc.getContext('2d');
    function resizeMC(){mc.width=window.innerWidth;mc.height=window.innerHeight}
    resizeMC();
    window.addEventListener('resize',resizeMC);

    var chars='アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ☠⚡◆◇⬡';
    var charArr=chars.split('');
    var fontSize=14;
    var columns=Math.floor(mc.width/fontSize);
    var drops=[];
    for(var i=0;i<columns;i++) drops[i]=Math.random()*mc.height/fontSize;

    function drawMatrix(){
        mx.fillStyle='rgba(10,10,10,0.05)';
        mx.fillRect(0,0,mc.width,mc.height);
        mx.font=fontSize+'px monospace';

        for(var i=0;i<drops.length;i++){
            var char=charArr[Math.floor(Math.random()*charArr.length)];
            // Alternate between blood red and dark red
            mx.fillStyle=Math.random()>.7?'rgba(220,20,60,0.8)':'rgba(139,0,0,0.5)';
            mx.fillText(char,i*fontSize,drops[i]*fontSize);

            if(drops[i]*fontSize>mc.height&&Math.random()>.975){
                drops[i]=0;
            }
            drops[i]++;
        }
        requestAnimationFrame(drawMatrix);
    }
    drawMatrix();
}

// ══════════════════════════
//  NAVBAR
// ══════════════════════════
var nav=document.getElementById('navbar');
var ham=document.getElementById('hamburger');
var navLinks=document.getElementById('navLinks');

window.addEventListener('scroll',function(){
    nav.classList.toggle('scrolled',window.scrollY>50);

    // Active section
    document.querySelectorAll('.section[id]').forEach(function(sec){
        var top=sec.offsetTop-120;
        var bot=top+sec.offsetHeight;
        var id=sec.id;
        var link=document.querySelector('.nav-link[href="#'+id+'"]');
        if(link){
            link.classList.toggle('active',window.scrollY>=top&&window.scrollY<bot);
        }
    });
});

if(ham){
    ham.addEventListener('click',function(){
        navLinks.classList.toggle('open');
    });
    document.querySelectorAll('.nav-link').forEach(function(l){
        l.addEventListener('click',function(){navLinks.classList.remove('open')});
    });
}

// ══════════════════════════
//  TYPING EFFECT
// ══════════════════════════
var typedEl=document.getElementById('typed');
if(typedEl){
    var phrases=[
        'We are the voice of the voiceless...',
        'Exposing government corruption worldwide...',
        'No system is safe from the truth...',
        'The corrupt will be exposed...',
        'Justice through digital resistance...',
        'Hacktivism is not a crime, it is a duty...'
    ];
    var pi=0,ci=0,deleting=false;

    function typeLoop(){
        var current=phrases[pi];
        if(deleting){
            typedEl.textContent=current.substring(0,ci-1);
            ci--;
        }else{
            typedEl.textContent=current.substring(0,ci+1);
            ci++;
        }

        var speed=deleting?30:70;

        if(!deleting&&ci===current.length){
            speed=2500;deleting=true;
        }else if(deleting&&ci===0){
            deleting=false;
            pi=(pi+1)%phrases.length;
            speed=500;
        }
        setTimeout(typeLoop,speed);
    }
    setTimeout(typeLoop,3000);
}

// ══════════════════════════
//  COUNTER ANIMATION
// ══════════════════════════
var counters=document.querySelectorAll('.hstat-num');
var counted=false;

function animCounters(){
    if(counted)return;
    counters.forEach(function(c){
        var target=parseInt(c.getAttribute('data-count'));
        var current=0;
        var inc=Math.max(1,Math.ceil(target/80));
        var timer=setInterval(function(){
            current+=inc;
            if(current>=target){current=target;clearInterval(timer)}
            c.textContent=current.toLocaleString();
        },30);
    });
    counted=true;
}

var statsEl=document.querySelector('.hero-stats');
if(statsEl){
    var sObs=new IntersectionObserver(function(e){
        e.forEach(function(en){if(en.isIntersecting)animCounters()});
    },{threshold:.5});
    sObs.observe(statsEl);
}

// ══════════════════════════
//  SCROLL ANIMATIONS
// ══════════════════════════
var animEls=document.querySelectorAll(
    '.m-card,.ally-card,.main-card,.exp-row,.sec-header,.exposed-terminal,.cta-wrap'
);
var aObs=new IntersectionObserver(function(entries){
    entries.forEach(function(e){
        if(e.isIntersecting){
            e.target.style.opacity='1';
            e.target.style.transform='translateY(0)';
        }
    });
},{threshold:.1,rootMargin:'0px 0px -40px 0px'});

animEls.forEach(function(el){
    el.style.opacity='0';
    el.style.transform='translateY(40px)';
    el.style.transition='opacity 0.7s ease, transform 0.7s ease';
    aObs.observe(el);
});

// ══════════════════════════
//  TERMINAL LINES
// ══════════════════════════
var termBody=document.getElementById('termBody');
if(termBody){
    var extraLines=[
        {t:'> Decrypting classified files... <span class="tg">DONE</span>',d:4000},
        {t:'> Uploading evidence to mirrors... <span class="tc">78%</span>',d:6000},
        {t:'> Target list updated: <span class="tr">5 NEW ENTRIES</span>',d:8000},
        {t:'> <span class="tr">☠ THE CORRUPT CANNOT HIDE ☠</span>',d:10000}
    ];
    extraLines.forEach(function(line){
        setTimeout(function(){
            var p=document.createElement('p');
            p.className='term-line';
            p.innerHTML=line.t;
            p.style.opacity='0';
            var input=termBody.querySelector('.term-input');
            termBody.insertBefore(p,input);
            setTimeout(function(){
                p.style.transition='opacity .4s';
                p.style.opacity='1';
            },50);
        },line.d);
    });
}

// ══════════════════════════
//  FOOTER SYS
// ══════════════════════════
var fSys=document.getElementById('footerSys');
if(fSys){
    setInterval(function(){
        var pid=Math.floor(Math.random()*9999);
        var node=Math.floor(Math.random()*999);
        fSys.textContent='SYS:ACTIVE | PID:'+pid+' | NODE:'+node;
    },3000);
}

// ══════════════════════════
//  SMOOTH SCROLL
// ══════════════════════════
document.querySelectorAll('a[href^="#"]').forEach(function(a){
    a.addEventListener('click',function(e){
        var href=this.getAttribute('href');
        if(href.length>1){
            e.preventDefault();
            var target=document.querySelector(href);
            if(target){
                target.scrollIntoView({behavior:'smooth',block:'start'});
            }
        }
    });
});

// ══════════════════════════
//  LOGO GLITCH ON HOVER
// ══════════════════════════
var heroLogo=document.getElementById('heroLogo');
if(heroLogo){
    heroLogo.addEventListener('mouseenter',function(){
        this.style.filter='hue-rotate(90deg) saturate(2) contrast(1.5)';
        setTimeout(function(){
            heroLogo.style.filter='saturate(1.2) contrast(1.1)';
        },200);
    });
}

})();