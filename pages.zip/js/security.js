(function(){
'use strict';

// Anti right-click
document.addEventListener('contextmenu',function(e){e.preventDefault()});

// Anti devtools shortcuts
document.addEventListener('keydown',function(e){
    if(e.key==='F12')e.preventDefault();
    if(e.ctrlKey&&e.shiftKey&&/[IJC]/.test(e.key))e.preventDefault();
    if(e.ctrlKey&&e.key==='u')e.preventDefault();
    if(e.ctrlKey&&e.key==='s')e.preventDefault();
});

// Anti drag
document.addEventListener('dragstart',function(e){e.preventDefault()});

// Anti iframe
if(window.self!==window.top)window.top.location=window.self.location;

// Anti automated
if(navigator.webdriver){
    document.body.innerHTML='<div style="background:#000;color:#8B0000;'+
        'height:100vh;display:flex;align-items:center;justify-content:center;'+
        'font-family:monospace;font-size:2rem">☠ ACCESS DENIED ☠</div>';
}

// DOM injection monitor
var obs=new MutationObserver(function(muts){
    muts.forEach(function(m){
        m.addedNodes.forEach(function(n){
            if(n.nodeType===1){
                var tag=n.tagName;
                if(tag==='IFRAME'||tag==='SCRIPT'||tag==='OBJECT'||tag==='EMBED'){
                    n.remove();
                }
            }
        });
    });
});
if(document.body){
    obs.observe(document.body,{childList:true,subtree:true});
}

// Console warning
console.log('%c☠ IRON ATLAS SECURITY ☠','color:#DC143C;font-size:24px;font-weight:bold');
console.log('%cAll access attempts are monitored and logged.','color:#ff3344;font-size:14px');

})();