/* ═══════════════════════════════════════════
   IRON ATLAS ☠ FORUM SYSTEM
   Uses Firebase Realtime Database (free tier)

   SETUP:
   1. Go to https://console.firebase.google.com
   2. Create project "iron-atlas-forum"
   3. Enable Realtime Database
   4. Set rules to allow read/write
   5. Replace config below with your values
   ═══════════════════════════════════════════ */

(function () {
    'use strict';

    // ════════════════════════════════════════
    //  FIREBASE CONFIG - REPLACE WITH YOURS
    // ════════════════════════════════════════
    var firebaseConfig = {
        apiKey: "YOUR_API_KEY",
        authDomain: "YOUR_PROJECT.firebaseapp.com",
        databaseURL: "https://YOUR_PROJECT-default-rtdb.firebaseio.com",
        projectId: "YOUR_PROJECT",
        storageBucket: "YOUR_PROJECT.appspot.com",
        messagingSenderId: "000000000000",
        appId: "YOUR_APP_ID"
    };

    // ════════════════════════════════════════
    //  ADMIN PASSWORD (change this!)
    // ════════════════════════════════════════
    var ADMIN_HASH = '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8';
    // Default: "password" - CHANGE THIS!
    // Generate your hash at: https://emn178.github.io/online-tools/sha256.html

    var isAdmin = false;
    var db = null;
    var messagesRef = null;
    var usingFirebase = false;

    // ── Init Firebase or fallback to localStorage ──
    try {
        if (firebaseConfig.apiKey !== "YOUR_API_KEY") {
            firebase.initializeApp(firebaseConfig);
            db = firebase.database();
            messagesRef = db.ref('forum/messages');
            usingFirebase = true;
            console.log('%c☠ Forum: Firebase connected', 'color:#00ff41');
        } else {
            throw new Error('Firebase not configured');
        }
    } catch (e) {
        console.log('%c☠ Forum: Using localStorage (configure Firebase for multi-user)',
            'color:#ffcc00');
        usingFirebase = false;
    }

    // ── Elements ──
    var msgList = document.getElementById('forumMessages');
    var postAlias = document.getElementById('postAlias');
    var postMessage = document.getElementById('postMessage');
    var postSubmit = document.getElementById('postSubmit');
    var adminToggle = document.getElementById('adminToggle');
    var adminModal = document.getElementById('adminModal');
    var adminPass = document.getElementById('adminPass');
    var adminLogin = document.getElementById('adminLogin');
    var adminCancel = document.getElementById('adminCancel');

    // ── SHA-256 hash ──
    async function sha256(text) {
        var encoder = new TextEncoder();
        var data = encoder.encode(text);
        var hash = await crypto.subtle.digest('SHA-256', data);
        var arr = Array.from(new Uint8Array(hash));
        return arr.map(function (b) { return b.toString(16).padStart(2, '0') }).join('');
    }

    // ── Sanitize input (XSS protection) ──
    function sanitize(str) {
        var div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    // ── Validate message ──
    function validate(alias, msg) {
        if (!alias.trim() || !msg.trim()) return false;
        if (alias.length > 30 || msg.length > 1000) return false;
        // Block URLs
        if (/https?:\/\//i.test(msg)) return false;
        if (/www\./i.test(msg)) return false;
        if (/\.com|\.net|\.org|\.io/i.test(msg)) return false;
        // Block script tags
        if (/<script/i.test(msg)) return false;
        if (/javascript:/i.test(msg)) return false;
        if (/on\w+=/i.test(msg)) return false;
        return true;
    }

    // ── Format timestamp ──
    function formatTime(ts) {
        var d = new Date(ts);
        var pad = function (n) { return n < 10 ? '0' + n : n };
        return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' +
            pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' +
            pad(d.getMinutes());
    }

    // ── Render message ──
    function renderMsg(id, data) {
        var li = document.createElement('li');
        li.className = 'forum-msg';
        li.setAttribute('data-id', id);
        li.innerHTML =
            '<div class="msg-header">' +
            '<span class="msg-author">☠ ' + sanitize(data.alias) + '</span>' +
            '<span class="msg-time">' + formatTime(data.timestamp) + '</span>' +
            '</div>' +
            '<div class="msg-body">' + sanitize(data.message) + '</div>' +
            '<button class="msg-delete" data-id="' + id + '">✕ DELETE</button>';

        // Delete handler
        li.querySelector('.msg-delete').addEventListener('click', function () {
            if (!isAdmin) return;
            if (confirm('Delete this message?')) {
                deleteMsg(id);
            }
        });

        return li;
    }

    // ── Load messages ──
    function loadMessages() {
        if (usingFirebase) {
            messagesRef.orderByChild('timestamp').on('value', function (snapshot) {
                msgList.innerHTML = '';
                var msgs = [];
                snapshot.forEach(function (child) {
                    msgs.push({ id: child.key, data: child.val() });
                });
                // Reverse for newest first
                msgs.reverse();
                if (msgs.length === 0) {
                    msgList.innerHTML =
                        '<li class="no-messages">> No hay mensajes aun. Se el primero. ☠</li>';
                    return;
                }
                msgs.forEach(function (m) {
                    msgList.appendChild(renderMsg(m.id, m.data));
                });
            });
        } else {
            // LocalStorage fallback
            var msgs = JSON.parse(localStorage.getItem('ia_forum') || '[]');
            msgList.innerHTML = '';
            if (msgs.length === 0) {
                msgList.innerHTML =
                    '<li class="no-messages">> No hay mensajes aun. Se el primero. ☠</li>';
                return;
            }
            msgs.reverse().forEach(function (m) {
                msgList.appendChild(renderMsg(m.id, m));
            });
        }
    }

    // ── Post message ──
    function postMsg() {
        var alias = postAlias.value.trim();
        var msg = postMessage.value.trim();

        if (!validate(alias, msg)) {
            alert('Mensaje invalido. Sin links, max 1000 chars.');
            return;
        }

        var data = {
            alias: alias,
            message: msg,
            timestamp: Date.now()
        };

        if (usingFirebase) {
            messagesRef.push(data);
        } else {
            var msgs = JSON.parse(localStorage.getItem('ia_forum') || '[]');
            data.id = 'msg_' + Date.now();
            msgs.push(data);
            localStorage.setItem('ia_forum', JSON.stringify(msgs));
            loadMessages();
        }

        postMessage.value = '';
    }

    // ── Delete message ──
    function deleteMsg(id) {
        if (!isAdmin) return;

        if (usingFirebase) {
            messagesRef.child(id).remove();
        } else {
            var msgs = JSON.parse(localStorage.getItem('ia_forum') || '[]');
            msgs = msgs.filter(function (m) { return m.id !== id });
            localStorage.setItem('ia_forum', JSON.stringify(msgs));
            loadMessages();
        }
    }

    // ── Admin ──
    adminToggle.addEventListener('click', function () {
        if (isAdmin) {
            isAdmin = false;
            document.body.classList.remove('admin-mode');
            adminToggle.classList.remove('active');
        } else {
            adminModal.classList.add('show');
            adminPass.value = '';
            adminPass.focus();
        }
    });

    adminLogin.addEventListener('click', async function () {
        var hash = await sha256(adminPass.value);
        if (hash === ADMIN_HASH) {
            isAdmin = true;
            document.body.classList.add('admin-mode');
            adminToggle.classList.add('active');
            adminModal.classList.remove('show');
        } else {
            alert('ACCESS DENIED');
            adminPass.value = '';
        }
    });

    adminPass.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') adminLogin.click();
    });

    adminCancel.addEventListener('click', function () {
        adminModal.classList.remove('show');
    });

    // ── Submit ──
    postSubmit.addEventListener('click', postMsg);
    postMessage.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && e.ctrlKey) postMsg();
    });

    // ── Rate limiting ──
    var lastPost = 0;
    var origPost = postMsg;
    postMsg = function () {
        var now = Date.now();
        if (now - lastPost < 5000) {
            alert('Espera 5 segundos entre mensajes.');
            return;
        }
        lastPost = now;
        origPost();
    };
    // Rebind
    postSubmit.onclick = postMsg;

    // ── Init ──
    loadMessages();

})();